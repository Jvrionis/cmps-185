#!/bin/bash
pdflatex jv_poker-cnn; bibtex jv_poker-cnn; pdflatex jv_poker-cnn.tex; pdflatex jv_poker-cnn.tex;